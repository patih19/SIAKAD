﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Hosting;
using System.Diagnostics;
using System.IO;

namespace akademik.am
{
    //public partial class WebForm12 : System.Web.UI.Page
    public partial class WebForm12 : Bak_staff
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}