﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace akademik.am
{
    //public partial class WebForm31 : System.Web.UI.Page 
    public partial class WebForm31 : Bak_staff
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void BtnInsert_Click(object sender, EventArgs e)
        {

        }
    }
}