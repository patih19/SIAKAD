﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;


namespace Padu.account
{
    //public partial class WebForm7 : System.Web.UI.Page
    public partial class WebForm7 : Mhs_account
    {
        //------------- LogOut ------------------------------//
        protected override void OnInit(EventArgs e)
        {
            // Your code
            base.OnInit(e);
            keluar.ServerClick += new EventHandler(logout_ServerClick);
        }

        protected void logout_ServerClick(object sender, EventArgs e)
        {
            //Your Code here....
            this.Session["Name"] = (object)null;
            this.Session["Passwd"] = (object)null;
            this.Session.Remove("Name");
            this.Session.Remove("Passwd");
            this.Session.RemoveAll();
            this.Response.Redirect("~/Padu_login.aspx");
        }
        // -------------- End Logout ----------------------------

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                // -----------------------------------Keterangan Biodata -----------------------------------------------
                string CS = ConfigurationManager.ConnectionStrings["MainDb"].ConnectionString;
                using (SqlConnection con = new SqlConnection(CS))
                {
                    con.Open();
                    //SqlTransaction trans = con.BeginTransaction();

                    SqlCommand CmdBiodata = new SqlCommand("SpBiodataMhs", con);
                    //CmdPeriodik.Transaction = trans;
                    CmdBiodata.CommandType = System.Data.CommandType.StoredProcedure;

                    CmdBiodata.Parameters.AddWithValue("@npm", this.Session["Name"].ToString());
                    // CmdBiodata.Parameters.AddWithValue("@no_tagihan", this.GVPendaftar.SelectedRow.Cells[1].Text);

                    using (SqlDataReader rdr = CmdBiodata.ExecuteReader())
                    {
                        if (rdr.HasRows)
                        {
                            while (rdr.Read())
                            {
                                this.TbNama.Text = rdr["nama"].ToString();
                                this.TbTmpLhir.Text = rdr["tmp_lahir"].ToString();
                                if (rdr["ttl"] == DBNull.Value)
                                {

                                }
                                else
                                {
                                    DateTime TglUjian = Convert.ToDateTime(rdr["ttl"]);
                                    this.TBTtl.Text = TglUjian.ToString("yyyy-MM-dd");
                                }

                                //this.LbGender.Text = rdr["gender"].ToString();
                                this.DLGender.SelectedValue = rdr["gender"].ToString();
                                this.DLAgama.SelectedValue = rdr["agama"].ToString();
                                this.DLDarah.SelectedValue = rdr["darah"].ToString();
                                this.TbAlamat.Text = rdr["alamat"].ToString();
                                //this.LbProv.Text = rdr["prov"].ToString();
                                //this.LbKotaKab.Text = rdr["kota"].ToString();
                                //this.LbKec.Text = rdr["kec"].ToString();
                                this.TbKdPOS.Text = rdr["kd_pos"].ToString();
                                this.TBHp.Text = rdr["hp"].ToString();
                                this.TbEmail.Text = rdr["email"].ToString();

                                this.TbSekolah.Text = rdr["sekolah"].ToString();
                                this.DLJurusan.SelectedValue= rdr["jurusan"].ToString();
                                this.DLStatusSekolah.SelectedValue = rdr["status_sekolah"].ToString();
                                this.TBThnLls.Text = rdr["thn_lls"].ToString();

                                this.TBAdik.Text = rdr["adik"].ToString();
                                this.TbKakak.Text = rdr["kakak"].ToString();
                                this.TbIbu.Text = rdr["ibu"].ToString();
                                this.TbAyah.Text = rdr["ayah"].ToString();
                                this.DLPendidikanAyah.SelectedValue= rdr["pendidikan_ayah"].ToString();
                                this.DLPendidikanIbu.SelectedValue = rdr["pendidikan_ibu"].ToString();
                                this.DLPekerjaanAyah.SelectedValue = rdr["pekerjaan_ayah"].ToString();
                                this.DLPekerjaanIbu.SelectedValue = rdr["pekerjaan_ibu"].ToString();
                                this.DLPenghasilan.SelectedValue = rdr["penghasilan_ortu"].ToString();
                            }
                        }
                    }
                }
            }
        }

        protected void BtnSave_Click(object sender, EventArgs e)
        {
            //form validation
            if (this.TbNama.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI NAMA');", true);
                return;
            }
            if (this.TbTmpLhir.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI KOTA/KAB. TEMPAT LAHIR');", true);
                return;
            }
            if (this.TBTtl.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI TANGGAL LAHIR');", true);
                return;
            }
            if (this.DLGender.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH JENIS KELAMIN');", true);
                return;
            }
            if (this.DLWarga.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH STATUS WARGA NEGARA');", true);
                return;
            }
            if (this.DLDarah.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH GOLONGAN DARAH');", true);
                return;
            }
            if (this.DropDownListProv.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH PROVINSI');", true);
                return;
            }
            if (this.DropDownListKab.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH KOTA/KABUPATEN');", true);
                return;
            }
            if (this.CascadingDropDownKec.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH KECAMATAN');", true);
                return;
            }

            if (this.TbAlamat.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI ALAMAT RUMAH');", true);
                return;
            }
            if (this.TbKdPOS.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI KODE POS ALAMAT RUMAH');", true);
                return;
            }
            if (this.TBHp.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI NOMOR HP');", true);
                return;
            }
            if (this.TbEmail.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI ALAMAT EMAIL');", true);
                return;
            }
            if (this.TbSekolah.Text == string.Empty || (this.TbSekolah.Text.Length < 6))
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI SEKOLAH ASAL SESUAI PETUNJUK');", true);
                return;
            }
            if (this.DLJurusan.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH JURUSAN');", true);
                return;
            }
            if (this.DLStatusSekolah.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH STATUS SEKOLAH');", true);
                return;
            }

            if (this.TBThnLls.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI TAHUN LULUS');", true);
                return;
            }
            if (this.TBAdik.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI JUMLAH ADIK');", true);
                return;
            }
            if (this.TbKakak.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI JUMLAH KAKAK');", true);
                return;
            }
            if (this.TbAyah.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI NAMA AYAH');", true);
                return;
            }
            if (this.TbIbu.Text == string.Empty)
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('ISI NAMA IBU');", true);
                return;
            }
            if (this.DLPendidikanAyah.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH PENDIDIKAN AYAH');", true);
                return;
            }
            if (this.DLPendidikanIbu.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH PENDIDIKAN IBU');", true);
                return;
            }
            if (this.DLPekerjaanIbu.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH PEKERJAAN IBU');", true);
                return;
            }
            if (this.DLPekerjaanAyah.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH PEKERJAAN AYAH');", true);
                return;
            }
            if (this.DLPenghasilan.SelectedValue == "-1")
            {
                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('PILIH KATEGORI PENGHASILAN');", true);
                return;
            }



            // ---------------- INSERT DATA -------------------------
            string CS = ConfigurationManager.ConnectionStrings["MainDb"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                con.Open();
                //SqlTransaction trans = con.BeginTransaction();

                SqlCommand CmdBiodata = new SqlCommand("SpUpdateMhs", con);
                //CmdPeriodik.Transaction = trans;
                CmdBiodata.CommandType = System.Data.CommandType.StoredProcedure;

                CmdBiodata.Parameters.AddWithValue("@npm", this.Session["Name"].ToString());
                CmdBiodata.Parameters.AddWithValue("@gdr",DLGender.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@agm",DLAgama.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@drh",DLDarah.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@prov",DropDownListProv.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@kota",DropDownListKab.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@kec",DropDownListKec.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@alamat",TbAlamat.Text);
                CmdBiodata.Parameters.AddWithValue("@tmplahir",TbTmpLhir.Text);
                CmdBiodata.Parameters.AddWithValue("@ttl",Convert.ToDateTime(TBTtl.Text));
                CmdBiodata.Parameters.AddWithValue("@pos",TbKdPOS.Text);
                CmdBiodata.Parameters.AddWithValue("@hp",TBHp.Text);
                CmdBiodata.Parameters.AddWithValue("@email",TbEmail.Text);
                CmdBiodata.Parameters.AddWithValue("@sch",TbSekolah.Text);
                CmdBiodata.Parameters.AddWithValue("@jrs",DLJurusan.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@stsch",DLStatusSekolah.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@thn_lls",TBThnLls.Text);
                CmdBiodata.Parameters.AddWithValue("@kakak", Convert.ToInt32(TbKakak.Text));
                CmdBiodata.Parameters.AddWithValue("@adk",Convert.ToInt32(TBAdik.Text));
                CmdBiodata.Parameters.AddWithValue("@ibu",TbIbu.Text);
                CmdBiodata.Parameters.AddWithValue("@ayah",TbAyah.Text);
                CmdBiodata.Parameters.AddWithValue("@pnd_ayah",DLPendidikanAyah.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@pnd_ibu",DLPendidikanIbu.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@pkj_ayah",DLPekerjaanAyah.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@pkj_ibu",DLPekerjaanIbu.SelectedItem.Text);
                CmdBiodata.Parameters.AddWithValue("@pghasil",DLPenghasilan.SelectedItem.Text);

                CmdBiodata.ExecuteNonQuery();

                Response.Redirect("~/account/Biodata.aspx");
            }
        }
    }
}